import { createContext, useContext, useEffect, useState } from "react";
import {
    createUserWithEmailAndPassword,
    signInWithEmailAndPassword,
    signOut,
    onAuthStateChanged,
    GoogleAuthProvider,
    signInWithPopup,
    sendPasswordResetEmail
} from "firebase/auth"
import { auth } from "../firebase";

const UserAuthContext = createContext ();


export function UserAuthContextProvider ({ children }) {
    const [user,setUser] = useState("");
    function signUp(email, password) {
        return createUserWithEmailAndPassword(auth, email, password);
    }
    function logIn(email, password) {
        console.log(email);
        return signInWithEmailAndPassword(auth, email, password);
    }
    function google(email, password) {
        console.log(email);
        const googleSignin = new GoogleAuthProvider();
        return signInWithPopup(auth,googleSignin);
    }
    function logOut() {
        return signOut(auth)
    }

    useEffect(()=>  {
        const unsubscribe = onAuthStateChanged(auth,(currentUser) =>{
            setUser(currentUser);
        });
        return () => {
            unsubscribe();
        }
    },[])
    return (
        <UserAuthContext.Provider value={{user, signUp, logIn, logOut, google}}>{children}</UserAuthContext.Provider>
    );
}

export function useUser() {
    return useContext(UserAuthContext);
}
