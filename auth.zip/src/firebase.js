import { initializeApp } from "firebase/app";
import {getAuth} from "firebase/auth"

const firebaseConfig = {
  apiKey: "AIzaSyCpKTgpNnr3lv5mrTy9VZ5_C6Qu-oPb7S0",
  authDomain: "signup-in-out.firebaseapp.com",
  projectId: "signup-in-out",
  storageBucket: "signup-in-out.appspot.com",
  messagingSenderId: "343618167549",
  appId: "1:343618167549:web:e4bc09f876225b2ad51494",
  measurementId: "G-L6LK6N94YJ"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth (app);
export default app;